@echo off
title Smart Lab - Student Workstation Agent
color 0B
cd /d "%~dp0"

echo =========================================================================
echo       SMART LAB COMMAND CENTER - STUDENT WORKSTATION AGENT
echo =========================================================================
echo.
set /p TEACHER_IP="Enter Teacher PC IP Address (e.g. 10.13.108.16): "
if "%TEACHER_IP%"=="" set TEACHER_IP=10.13.108.16

set /p PC_ID="Enter Workstation ID (press Enter for LAB-PC-02): "
if "%PC_ID%"=="" set PC_ID=LAB-PC-02

set /p S_NAME="Enter Student Name (press Enter for Student 2): "
if "%S_NAME%"=="" set S_NAME=Student 2

echo.
echo Connecting to Teacher Server at %TEACHER_IP%:8500...
echo Workstation: %PC_ID% (%S_NAME%)
echo.
python -m agent.client_agent --host %TEACHER_IP% --port 8500 --client-id %PC_ID% --student "%S_NAME%"
pause
